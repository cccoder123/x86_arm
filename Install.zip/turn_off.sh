sudo dpkg --remove-architecture amd64
sudo dpkg --remove-architecture i386
sudo dpkg --remove-architecture i686
sudo apt update
rm -r /x86
echo "Your device is in arm mode"